package com.airbnb.lottie;

public interface LottieOnCompositionLoadedListener {
  void onCompositionLoaded(LottieComposition composition);
}
