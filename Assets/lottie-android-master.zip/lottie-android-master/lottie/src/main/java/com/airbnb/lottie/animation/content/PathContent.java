package com.airbnb.lottie.animation.content;

import android.graphics.Path;

interface PathContent extends Content {
  Path getPath();
}
