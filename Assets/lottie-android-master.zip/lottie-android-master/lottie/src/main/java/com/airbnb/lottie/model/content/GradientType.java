package com.airbnb.lottie.model.content;

public enum GradientType {
  LINEAR,
  RADIAL
}
